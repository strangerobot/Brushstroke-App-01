Needs latest version of Java, http://java.com/download

#Output
1.The PDF will be really huge and difficult to handle
2.The image is a large 8000x8000 PNG file.
3.Both in Outut folder
4.Saving might take a few minutes
5. Results might be different from preview